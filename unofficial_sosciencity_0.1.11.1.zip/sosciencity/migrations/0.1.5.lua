global.warning_ticks[9] = -3600
