Tirislib.Prototype.batch_create {
    {
        type = "recipe-category",
        name = "sosciencity-algae-farm"
    },
    {
        type = "recipe-category",
        name = "sosciencity-animal-farming"
    },
    {
        type = "recipe-category",
        name = "sosciencity-architecture"
    },
    {
        type = "recipe-category",
        name = "sosciencity-biological-clarifier"
    },
    {
        type = "recipe-category",
        name = "sosciencity-bioreactor"
    },
    {
        type = "recipe-category",
        name = "sosciencity-bloomhouse-annual"
    },
    {
        type = "recipe-category",
        name = "sosciencity-bloomhouse-perennial"
    },
    {
        type = "recipe-category",
        name = "sosciencity-chemical-clarifier"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-clockwork"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-orchid"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-gunfire"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-ember"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-foundry"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-gleam"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-aurora"
    },
    {
        type = "recipe-category",
        name = "sosciencity-caste-plasma"
    },
    {
        type = "recipe-category",
        name = "sosciencity-computing-center"
    },
    {
        type = "recipe-category",
        name = "sosciencity-drying-unit"
    },
    {
        type = "recipe-category",
        name = "sosciencity-farming-annual"
    },
    {
        type = "recipe-category",
        name = "sosciencity-farming-perennial"
    },
    {
        type = "recipe-category",
        name = "sosciencity-fermentation-tank"
    },
    {
        type = "recipe-category",
        name = "sosciencity-fishery"
    },
    {
        type = "recipe-category",
        name = "sosciencity-fishery-hand"
    },
    {
        type = "recipe-category",
        name = "sosciencity-groundwater-pump"
    },
    {
        type = "recipe-category",
        name = "sosciencity-handcrafting"
    },
    {
        type = "recipe-category",
        name = "sosciencity-hunting"
    },
    {
        type = "recipe-category",
        name = "sosciencity-mushroom-farm"
    },
    {
        type = "recipe-category",
        name = "sosciencity-orchid-food-processing"
    },
    {
        type = "recipe-category",
        name = "sosciencity-pharma"
    },
    {
        type = "recipe-category",
        name = "sosciencity-phyto-gene-lab"
    },
    {
        type = "recipe-category",
        name = "sosciencity-reproductive-gene-lab"
    },
    {
        type = "recipe-category",
        name = "sosciencity-salt-pond"
    },
    {
        type = "recipe-category",
        name = "sosciencity-sedimentation-clarifier"
    },
    {
        type = "recipe-category",
        name = "sosciencity-slaughter"
    },
    {
        type = "recipe-category",
        name = "sosciencity-sorting-machine"
    },
    {
        type = "recipe-category",
        name = "sosciencity-plant-upbringing"
    },
    {
        type = "recipe-category",
        name = "sosciencity-water-agriculture"
    },
    {
        type = "recipe-category",
        name = "sosciencity-water-animal-farming"
    },
    {
        type = "recipe-category",
        name = "sosciencity-wood-processing"
    }
}
