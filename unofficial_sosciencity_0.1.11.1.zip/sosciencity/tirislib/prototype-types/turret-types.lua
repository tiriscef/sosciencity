return {
    "ammo-turret",
    "electric-turret",
    "fluid-turret",
    "turret"
}
