--- Enum table for temperatures
local Climate = {}

Climate.hot = 1
Climate.temperate = 2
Climate.cold = 3

return Climate
