--- Enum table for types of conditions.
local Condition = {}

Condition.custom = 0
Condition.item_aquisition = 1
Condition.caste_points = 2

return Condition
