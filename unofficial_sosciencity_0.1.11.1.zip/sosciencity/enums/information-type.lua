--- Enum table for information types
local InformationType = {}

InformationType.acquisition_unlock = 1
InformationType.unlocked_gated_technology = 2

return InformationType
