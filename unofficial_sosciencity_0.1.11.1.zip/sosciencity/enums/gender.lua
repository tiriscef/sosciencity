--- Enum table for genders
local Gender = {}

Gender.agender = 1
Gender.fale = 2
Gender.pachin = 3
Gender.ga = 4

return Gender
