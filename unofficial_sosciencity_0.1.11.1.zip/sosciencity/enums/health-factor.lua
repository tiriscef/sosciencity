--- Enum table for health factors.
local HealthFactor = {}

HealthFactor.hunger = 1
HealthFactor.thirst = 2

return HealthFactor
