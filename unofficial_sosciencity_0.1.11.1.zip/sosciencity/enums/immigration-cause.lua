--- Enum table for immigration causes
local ImmigrationCause = {}

ImmigrationCause.birth = 1

return ImmigrationCause
