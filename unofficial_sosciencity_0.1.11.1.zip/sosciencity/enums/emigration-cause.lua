--- Enum table for emigration causes
local EmigrationCause = {}

EmigrationCause.unknown = 0
EmigrationCause.unhappy = 1
EmigrationCause.homeless = 2

return EmigrationCause
