--- Enum table for sanity factors.
local SanityFactor = {}

-- nothing here, yet
--SanityFactor.hunger = 1
--SanityFactor.thirst = 2

return SanityFactor
