--- Enum table for humidity
local Humidity = {}

Humidity.humid = 1
Humidity.moderate = 2
Humidity.dry = 3

return Humidity
