Sosciencity_Config.add_glass = false
