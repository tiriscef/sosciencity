--"clean-water" = "purified-water"
--Sosciencity_Config.add_clean-water = false

-- Failed attempt at crossing the purified water from angels refinery with clean water from guess -Koi
