Sosciencity_Config.add_glass = false
Sosciencity_Config.lumber_in_vanilla_recipes = false
