Sosciencity_Config.lumber_in_vanilla_recipes = false
