-- remove the dublicate water filter
data.raw.item["water-filter"] = nil
