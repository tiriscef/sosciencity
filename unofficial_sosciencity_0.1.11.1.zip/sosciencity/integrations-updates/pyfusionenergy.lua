-- quick and rather dirty fix for https://github.com/tiriscef/sosciencity/issues/4

Tirislib.Recipe.get_by_name("production-science-pack").subgroup = "science-pack"
