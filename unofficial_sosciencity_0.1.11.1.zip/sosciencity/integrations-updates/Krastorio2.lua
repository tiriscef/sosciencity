-- remove the weird potato item from krastorio2 to avoid the name conflict with sosciencity's potatoes
data.raw.capsule.potato = nil
