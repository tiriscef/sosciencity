--- Things that people like (and need) to drink.
local DrinkingWater = {}

DrinkingWater.values = {
    ["clean-water"] = 2,
    ["drinkable-water"] = 0.5,
    ["water"] = -5,
    ["mechanically-cleaned-water"] = -3,
    ["biologically-cleaned-water"] = -1,
    ["ultra-pure-water"] = -2
}

return DrinkingWater
